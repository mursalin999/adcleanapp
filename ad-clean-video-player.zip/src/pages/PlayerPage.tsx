import { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Play, ExternalLink, Eye, EyeOff, Moon, Sun, Volume2, VolumeX,
  Plus, Trash2, Clock, Save, StickyNote, AlertCircle, Shield
} from 'lucide-react';
import { detectPlatform, getEmbedUrl, getVideoTitle, getVideoThumbnail, isValidUrl, PLATFORMS, parseTime, formatTime } from '../utils/platform';
import { useAuthStore, useVideosStore, usePlayerStore } from '../store';
import type { SkipSegment, Platform } from '../types';

export function PlayerPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const initialUrl = searchParams.get('url') || '';

  const [url, setUrl] = useState(initialUrl);
  const [activeUrl, setActiveUrl] = useState(initialUrl);
  const [error, setError] = useState('');
  const [notes, setNotes] = useState('');
  const [localSegments, setLocalSegments] = useState<SkipSegment[]>([]);
  const [newStart, setNewStart] = useState('');
  const [newEnd, setNewEnd] = useState('');
  const [newType, setNewType] = useState<'skip' | 'mute'>('skip');
  const [saved, setSaved] = useState(false);

  const { user, isAuthenticated } = useAuthStore();
  const { addVideo } = useVideosStore();
  const { focusMode, hideSuggestions, autoMuteAds, setFocusMode, setHideSuggestions, setAutoMuteAds } = usePlayerStore();

  const platform: Platform = activeUrl ? detectPlatform(activeUrl) : 'unknown';
  const platformInfo = PLATFORMS[platform];
  const embedUrl = activeUrl ? getEmbedUrl(activeUrl, platform, hideSuggestions) : null;

  // Apply user default preferences
  useEffect(() => {
    if (user?.preferences) {
      setFocusMode(user.preferences.defaultFocusMode);
      setHideSuggestions(user.preferences.defaultHideSuggestions);
      setAutoMuteAds(user.preferences.defaultAutoMute);
    }
  }, [user, setFocusMode, setHideSuggestions, setAutoMuteAds]);

  const handleLoad = useCallback((e?: React.FormEvent) => {
    e?.preventDefault();
    if (!url.trim()) {
      setError('Please paste a video URL');
      return;
    }
    if (!isValidUrl(url.trim())) {
      setError('Please enter a valid URL');
      return;
    }
    setError('');
    setActiveUrl(url.trim());
    setLocalSegments([]);
    setNotes('');
    setSaved(false);
    navigate(`/player?url=${encodeURIComponent(url.trim())}`, { replace: true });
  }, [url, navigate]);

  const addSegment = () => {
    if (!newStart || !newEnd) return;
    const start = parseTime(newStart);
    const end = parseTime(newEnd);
    if (end <= start) return;
    const seg: SkipSegment = {
      id: Math.random().toString(36).substr(2, 9),
      startTime: start,
      endTime: end,
      type: newType,
      label: `${newType === 'skip' ? 'Skip' : 'Mute'} segment`,
    };
    setLocalSegments([...localSegments, seg]);
    setNewStart('');
    setNewEnd('');
  };

  const removeSegment = (id: string) => {
    setLocalSegments(localSegments.filter(s => s.id !== id));
  };

  const handleSave = () => {
    if (!isAuthenticated || !user) return;
    addVideo({
      userId: user.id,
      platform,
      url: activeUrl,
      title: getVideoTitle(activeUrl, platform),
      thumbnail: getVideoThumbnail(activeUrl, platform),
      segments: localSegments,
      notes,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="relative">
      {/* Focus Mode Overlay */}
      {focusMode && <div className="focus-overlay" />}

      {/* URL Input */}
      <form onSubmit={handleLoad} className="mb-6">
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <ExternalLink className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              value={url}
              onChange={(e) => { setUrl(e.target.value); setError(''); }}
              placeholder="Paste a video URL..."
              className="w-full rounded-xl border border-surface-lighter bg-surface-light py-3 pl-12 pr-4 text-white placeholder-gray-500 outline-none focus:border-primary focus:ring-2 focus:ring-primary/30"
            />
          </div>
          <button
            type="submit"
            className="flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 font-semibold text-white transition hover:bg-primary-dark"
          >
            <Play className="h-4 w-4" />
            Load Video
          </button>
        </div>
        {error && <p className="mt-2 text-sm text-red-400">{error}</p>}
      </form>

      <div className="grid gap-6 lg:grid-cols-[1fr,380px]">
        {/* Video Player */}
        <div className={focusMode ? 'focus-content' : ''}>
          {activeUrl && platformInfo.supported && embedUrl ? (
            <div>
              {/* Platform Badge */}
              <div className="mb-3 flex items-center gap-2">
                <span
                  className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium text-white"
                  style={{ backgroundColor: platformInfo.color + '33', color: platformInfo.color }}
                >
                  {platformInfo.icon} {platformInfo.name}
                </span>
                <span className="text-sm text-gray-500 truncate max-w-md">{activeUrl}</span>
              </div>

              {/* Embed */}
              <div className="embed-container rounded-2xl overflow-hidden border border-surface-lighter shadow-2xl shadow-black/30">
                <iframe
                  src={embedUrl}
                  title={`${platformInfo.name} video`}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>

              {/* Segment Timeline Visual */}
              {localSegments.length > 0 && (
                <div className="mt-4">
                  <p className="mb-2 text-xs font-medium text-gray-400">Marked Segments</p>
                  <div className="relative h-6 rounded-full bg-surface-lighter overflow-hidden">
                    {localSegments.map((seg) => {
                      const maxEnd = Math.max(...localSegments.map(s => s.endTime), 600);
                      const left = (seg.startTime / maxEnd) * 100;
                      const width = ((seg.endTime - seg.startTime) / maxEnd) * 100;
                      return (
                        <div
                          key={seg.id}
                          className="segment-marker flex items-center justify-center text-[9px] font-medium text-white"
                          style={{ left: `${left}%`, width: `${Math.max(width, 1)}%` }}
                          title={`${formatTime(seg.startTime)} - ${formatTime(seg.endTime)} (${seg.type})`}
                        >
                          {seg.type === 'mute' ? <VolumeX className="h-3 w-3" /> : '→'}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : activeUrl && !platformInfo.supported ? (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-surface-lighter bg-surface-light p-16 text-center">
              <AlertCircle className="mb-4 h-12 w-12 text-yellow-500" />
              <h3 className="mb-2 text-xl font-bold">Platform Not Supported Yet</h3>
              <p className="text-sm text-gray-400">
                {platformInfo.name} is not currently supported. We only use official embed APIs and this platform
                doesn't provide one we can use, or support is coming soon.
              </p>
              <p className="mt-4 text-xs text-gray-600">
                Supported platforms: YouTube, Vimeo, Facebook, TikTok
              </p>
            </div>
          ) : activeUrl && !embedUrl ? (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-surface-lighter bg-surface-light p-16 text-center">
              <AlertCircle className="mb-4 h-12 w-12 text-yellow-500" />
              <h3 className="mb-2 text-xl font-bold">Could Not Load Video</h3>
              <p className="text-sm text-gray-400">
                The URL format wasn't recognized. Please check the link and try again.
              </p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-surface-lighter bg-surface-light/50 p-20 text-center">
              <Play className="mb-4 h-16 w-16 text-surface-lighter" />
              <h3 className="mb-2 text-xl font-semibold text-gray-400">No Video Loaded</h3>
              <p className="text-sm text-gray-600">Paste a video URL above to get started</p>
            </div>
          )}
        </div>

        {/* Controls Panel */}
        <div className={`space-y-4 ${focusMode ? 'focus-content' : ''}`}>
          {/* Focus & Display Controls */}
          <div className="rounded-2xl border border-surface-lighter bg-surface-light p-5">
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-gray-400">Display Controls</h3>

            <div className="space-y-3">
              <label className="flex cursor-pointer items-center justify-between rounded-xl bg-surface p-3 transition hover:bg-surface-lighter">
                <div className="flex items-center gap-3">
                  {focusMode ? <Moon className="h-5 w-5 text-primary" /> : <Sun className="h-5 w-5 text-gray-500" />}
                  <div>
                    <p className="text-sm font-medium">Focus Mode</p>
                    <p className="text-xs text-gray-500">Dim everything except the player</p>
                  </div>
                </div>
                <button
                  onClick={() => setFocusMode(!focusMode)}
                  className={`relative h-6 w-11 rounded-full transition-colors ${
                    focusMode ? 'bg-primary' : 'bg-surface-lighter'
                  }`}
                >
                  <span
                    className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
                      focusMode ? 'translate-x-5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </label>

              <label className="flex cursor-pointer items-center justify-between rounded-xl bg-surface p-3 transition hover:bg-surface-lighter">
                <div className="flex items-center gap-3">
                  {hideSuggestions ? <EyeOff className="h-5 w-5 text-primary" /> : <Eye className="h-5 w-5 text-gray-500" />}
                  <div>
                    <p className="text-sm font-medium">Hide Suggestions</p>
                    <p className="text-xs text-gray-500">Reduce recommended videos (if possible)</p>
                  </div>
                </div>
                <button
                  onClick={() => setHideSuggestions(!hideSuggestions)}
                  className={`relative h-6 w-11 rounded-full transition-colors ${
                    hideSuggestions ? 'bg-primary' : 'bg-surface-lighter'
                  }`}
                >
                  <span
                    className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
                      hideSuggestions ? 'translate-x-5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </label>

              <label className="flex cursor-pointer items-center justify-between rounded-xl bg-surface p-3 transition hover:bg-surface-lighter">
                <div className="flex items-center gap-3">
                  {autoMuteAds ? <VolumeX className="h-5 w-5 text-primary" /> : <Volume2 className="h-5 w-5 text-gray-500" />}
                  <div>
                    <p className="text-sm font-medium">Auto-Mute Ad Segments</p>
                    <p className="text-xs text-gray-500">Mute during marked segments</p>
                  </div>
                </div>
                <button
                  onClick={() => setAutoMuteAds(!autoMuteAds)}
                  className={`relative h-6 w-11 rounded-full transition-colors ${
                    autoMuteAds ? 'bg-primary' : 'bg-surface-lighter'
                  }`}
                >
                  <span
                    className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
                      autoMuteAds ? 'translate-x-5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </label>
            </div>
          </div>

          {/* Ad Control */}
          <div className="rounded-2xl border border-surface-lighter bg-surface-light p-5">
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-gray-400">
              Ad Control (Within Rules)
            </h3>

            <div className="mb-4 rounded-xl border border-primary/20 bg-primary/5 p-3">
              <p className="flex items-start gap-2 text-xs text-primary-light">
                <Shield className="mt-0.5 h-4 w-4 shrink-0" />
                Mark sections you want to skip or mute. Uses only standard player controls.
              </p>
            </div>

            {/* Add Segment */}
            <div className="mb-4 space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="mb-1 block text-xs text-gray-500">Start (mm:ss)</label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-600" />
                    <input
                      type="text"
                      value={newStart}
                      onChange={(e) => setNewStart(e.target.value)}
                      placeholder="00:00"
                      className="w-full rounded-lg border border-surface-lighter bg-surface py-2 pl-9 pr-3 text-sm text-white placeholder-gray-600 outline-none focus:border-primary"
                    />
                  </div>
                </div>
                <div>
                  <label className="mb-1 block text-xs text-gray-500">End (mm:ss)</label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-600" />
                    <input
                      type="text"
                      value={newEnd}
                      onChange={(e) => setNewEnd(e.target.value)}
                      placeholder="00:30"
                      className="w-full rounded-lg border border-surface-lighter bg-surface py-2 pl-9 pr-3 text-sm text-white placeholder-gray-600 outline-none focus:border-primary"
                    />
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setNewType('skip')}
                  className={`flex-1 rounded-lg py-2 text-xs font-medium transition ${
                    newType === 'skip'
                      ? 'bg-red-500/20 text-red-400 ring-1 ring-red-500/40'
                      : 'bg-surface text-gray-500 hover:bg-surface-lighter'
                  }`}
                >
                  Skip
                </button>
                <button
                  onClick={() => setNewType('mute')}
                  className={`flex-1 rounded-lg py-2 text-xs font-medium transition ${
                    newType === 'mute'
                      ? 'bg-yellow-500/20 text-yellow-400 ring-1 ring-yellow-500/40'
                      : 'bg-surface text-gray-500 hover:bg-surface-lighter'
                  }`}
                >
                  Mute
                </button>
              </div>

              <button
                onClick={addSegment}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary/20 py-2 text-sm font-medium text-primary-light transition hover:bg-primary/30"
              >
                <Plus className="h-4 w-4" />
                Add Segment
              </button>
            </div>

            {/* Segments List */}
            {localSegments.length > 0 && (
              <div className="space-y-2">
                {localSegments.map((seg) => (
                  <div
                    key={seg.id}
                    className="flex items-center justify-between rounded-lg bg-surface p-3"
                  >
                    <div className="flex items-center gap-3">
                      {seg.type === 'skip' ? (
                        <span className="rounded bg-red-500/20 px-2 py-0.5 text-xs font-medium text-red-400">SKIP</span>
                      ) : (
                        <span className="rounded bg-yellow-500/20 px-2 py-0.5 text-xs font-medium text-yellow-400">MUTE</span>
                      )}
                      <span className="text-sm text-gray-300">
                        {formatTime(seg.startTime)} → {formatTime(seg.endTime)}
                      </span>
                    </div>
                    <button
                      onClick={() => removeSegment(seg.id)}
                      className="rounded p-1 text-gray-600 transition hover:bg-surface-lighter hover:text-red-400"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Notes */}
          <div className="rounded-2xl border border-surface-lighter bg-surface-light p-5">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-gray-400">
              <StickyNote className="h-4 w-4" />
              Notes
            </h3>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add notes about this video..."
              rows={3}
              className="w-full rounded-lg border border-surface-lighter bg-surface p-3 text-sm text-white placeholder-gray-600 outline-none resize-none focus:border-primary"
            />
          </div>

          {/* Save */}
          {isAuthenticated && activeUrl && (
            <button
              onClick={handleSave}
              className={`flex w-full items-center justify-center gap-2 rounded-xl py-3 font-semibold transition ${
                saved
                  ? 'bg-green-500/20 text-green-400'
                  : 'bg-primary text-white hover:bg-primary-dark'
              }`}
            >
              <Save className="h-4 w-4" />
              {saved ? 'Saved!' : 'Save to My Videos'}
            </button>
          )}

          {!isAuthenticated && (
            <p className="text-center text-xs text-gray-600">
              <a href="/auth" className="text-primary hover:underline">Sign in</a> to save videos and preferences
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
