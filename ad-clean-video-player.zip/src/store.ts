import { create } from 'zustand';
import type { User, UserPreferences, SavedVideo, SkipSegment } from './types';

function generateId(): string {
  return Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
}

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : fallback;
  } catch {
    return fallback;
  }
}

function saveToStorage(key: string, data: unknown): void {
  localStorage.setItem(key, JSON.stringify(data));
}

// Auth Store
interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => boolean;
  register: (email: string, password: string, name: string) => boolean;
  logout: () => void;
  updatePreferences: (prefs: Partial<UserPreferences>) => void;
  updateProfile: (name: string, email: string) => void;
  deleteAccount: () => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: loadFromStorage<User | null>('adclean_user', null),
  isAuthenticated: !!loadFromStorage<User | null>('adclean_user', null),

  login: (email: string, password: string) => {
    const users = loadFromStorage<Array<{ user: User; password: string }>>('adclean_users', []);
    const found = users.find(u => u.user.email === email && u.password === password);
    if (found) {
      set({ user: found.user, isAuthenticated: true });
      saveToStorage('adclean_user', found.user);
      return true;
    }
    return false;
  },

  register: (email: string, password: string, name: string) => {
    const users = loadFromStorage<Array<{ user: User; password: string }>>('adclean_users', []);
    if (users.find(u => u.user.email === email)) return false;
    const newUser: User = {
      id: generateId(),
      email,
      name,
      createdAt: new Date().toISOString(),
      preferences: {
        theme: 'dark',
        defaultFocusMode: false,
        defaultHideSuggestions: true,
        defaultAutoMute: true,
      },
    };
    users.push({ user: newUser, password });
    saveToStorage('adclean_users', users);
    set({ user: newUser, isAuthenticated: true });
    saveToStorage('adclean_user', newUser);
    return true;
  },

  logout: () => {
    set({ user: null, isAuthenticated: false });
    localStorage.removeItem('adclean_user');
  },

  updatePreferences: (prefs: Partial<UserPreferences>) => {
    const { user } = get();
    if (!user) return;
    const updated = { ...user, preferences: { ...user.preferences, ...prefs } };
    set({ user: updated });
    saveToStorage('adclean_user', updated);
    const users = loadFromStorage<Array<{ user: User; password: string }>>('adclean_users', []);
    const idx = users.findIndex(u => u.user.id === user.id);
    if (idx >= 0) {
      users[idx].user = updated;
      saveToStorage('adclean_users', users);
    }
  },

  updateProfile: (name: string, email: string) => {
    const { user } = get();
    if (!user) return;
    const updated = { ...user, name, email };
    set({ user: updated });
    saveToStorage('adclean_user', updated);
    const users = loadFromStorage<Array<{ user: User; password: string }>>('adclean_users', []);
    const idx = users.findIndex(u => u.user.id === user.id);
    if (idx >= 0) {
      users[idx].user = updated;
      saveToStorage('adclean_users', users);
    }
  },

  deleteAccount: () => {
    const { user } = get();
    if (!user) return;
    const users = loadFromStorage<Array<{ user: User; password: string }>>('adclean_users', []);
    const filtered = users.filter(u => u.user.id !== user.id);
    saveToStorage('adclean_users', filtered);
    // Remove user's videos
    const videos = loadFromStorage<SavedVideo[]>('adclean_videos', []);
    saveToStorage('adclean_videos', videos.filter(v => v.userId !== user.id));
    set({ user: null, isAuthenticated: false });
    localStorage.removeItem('adclean_user');
  },
}));

// Videos Store
interface VideosState {
  videos: SavedVideo[];
  loadVideos: (userId: string) => void;
  addVideo: (video: Omit<SavedVideo, 'id' | 'dateAdded'>) => SavedVideo;
  updateVideo: (id: string, updates: Partial<SavedVideo>) => void;
  deleteVideo: (id: string) => void;
  addSegment: (videoId: string, segment: Omit<SkipSegment, 'id'>) => void;
  removeSegment: (videoId: string, segmentId: string) => void;
}

export const useVideosStore = create<VideosState>((set, get) => ({
  videos: [],

  loadVideos: (userId: string) => {
    const all = loadFromStorage<SavedVideo[]>('adclean_videos', []);
    set({ videos: all.filter(v => v.userId === userId) });
  },

  addVideo: (video) => {
    const newVideo: SavedVideo = {
      ...video,
      id: generateId(),
      dateAdded: new Date().toISOString(),
    };
    const all = loadFromStorage<SavedVideo[]>('adclean_videos', []);
    all.push(newVideo);
    saveToStorage('adclean_videos', all);
    set({ videos: [...get().videos, newVideo] });
    return newVideo;
  },

  updateVideo: (id, updates) => {
    const all = loadFromStorage<SavedVideo[]>('adclean_videos', []);
    const idx = all.findIndex(v => v.id === id);
    if (idx >= 0) {
      all[idx] = { ...all[idx], ...updates };
      saveToStorage('adclean_videos', all);
      set({ videos: get().videos.map(v => v.id === id ? { ...v, ...updates } : v) });
    }
  },

  deleteVideo: (id) => {
    const all = loadFromStorage<SavedVideo[]>('adclean_videos', []);
    saveToStorage('adclean_videos', all.filter(v => v.id !== id));
    set({ videos: get().videos.filter(v => v.id !== id) });
  },

  addSegment: (videoId, segment) => {
    const newSegment: SkipSegment = { ...segment, id: generateId() };
    const { videos } = get();
    const video = videos.find(v => v.id === videoId);
    if (video) {
      const updated = { ...video, segments: [...video.segments, newSegment] };
      get().updateVideo(videoId, { segments: updated.segments });
    }
  },

  removeSegment: (videoId, segmentId) => {
    const { videos } = get();
    const video = videos.find(v => v.id === videoId);
    if (video) {
      const updated = { ...video, segments: video.segments.filter(s => s.id !== segmentId) };
      get().updateVideo(videoId, { segments: updated.segments });
    }
  },
}));

// Player Store
interface PlayerState {
  focusMode: boolean;
  hideSuggestions: boolean;
  autoMuteAds: boolean;
  setFocusMode: (v: boolean) => void;
  setHideSuggestions: (v: boolean) => void;
  setAutoMuteAds: (v: boolean) => void;
}

export const usePlayerStore = create<PlayerState>((set) => ({
  focusMode: false,
  hideSuggestions: true,
  autoMuteAds: true,
  setFocusMode: (v) => set({ focusMode: v }),
  setHideSuggestions: (v) => set({ hideSuggestions: v }),
  setAutoMuteAds: (v) => set({ autoMuteAds: v }),
}));
