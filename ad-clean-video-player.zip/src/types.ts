export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
  preferences: UserPreferences;
}

export interface UserPreferences {
  theme: 'dark' | 'light';
  defaultFocusMode: boolean;
  defaultHideSuggestions: boolean;
  defaultAutoMute: boolean;
}

export interface SkipSegment {
  id: string;
  startTime: number; // seconds
  endTime: number; // seconds
  type: 'skip' | 'mute';
  label?: string;
}

export interface SavedVideo {
  id: string;
  userId: string;
  platform: string;
  url: string;
  title: string;
  thumbnail: string;
  dateAdded: string;
  segments: SkipSegment[];
  notes: string;
}

export type Platform = 'youtube' | 'facebook' | 'instagram' | 'tiktok' | 'twitter' | 'vimeo' | 'unknown';

export interface PlatformInfo {
  name: string;
  icon: string;
  color: string;
  supported: boolean;
}
