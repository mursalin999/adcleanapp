export interface User {
  id: number;
  email: string;
  name: string;
  preferences: {
    darkMode?: boolean;
    autoFocus?: boolean;
  };
}

export interface VideoSegment {
  id: string;
  start: number; // in seconds
  end: number;   // in seconds
  type: 'skip' | 'mute';
  label?: string;
}

export interface Video {
  id: number;
  user_id: number;
  platform: string;
  url: string;
  title: string;
  thumbnail: string;
  segments: VideoSegment[];
  notes: string;
  created_at?: string;
}
