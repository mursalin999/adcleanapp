import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Play, Shield, EyeOff, LayoutTemplate } from 'lucide-react';

export function Landing() {
  const [url, setUrl] = useState('');
  const navigate = useNavigate();

  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) {
      navigate(`/player?url=${encodeURIComponent(url)}`);
    }
  };

  return (
    <div className="space-y-24 pb-20">
      {/* Hero Section */}
      <section className="text-center space-y-8 pt-10">
        <h1 className="text-5xl md:text-7xl font-bold tracking-tighter bg-gradient-to-r from-white to-zinc-500 bg-clip-text text-transparent">
          Focus on the content,<br />not the clutter.
        </h1>
        <p className="text-xl text-zinc-400 max-w-2xl mx-auto leading-relaxed">
          Watch social media videos with fewer distractions. Hide recommendations, 
          darken the UI, and mute unwanted segments automatically.
        </p>
        
        <form onSubmit={handleStart} className="max-w-xl mx-auto relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-teal-600 to-purple-600 rounded-lg blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative flex">
            <input 
              type="text" 
              placeholder="Paste a YouTube or Vimeo link here..." 
              className="w-full bg-zinc-900 border border-zinc-800 rounded-l-lg py-4 px-6 text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-teal-500 transition-all"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
            <button 
              type="submit"
              className="bg-zinc-100 hover:bg-white text-zinc-900 font-bold py-4 px-8 rounded-r-lg transition-colors flex items-center gap-2"
            >
              <Play className="w-5 h-5 fill-current" />
              Watch
            </button>
          </div>
        </form>
        <p className="text-sm text-zinc-600">
          Supports YouTube, Vimeo, Twitch, SoundCloud, and more.
        </p>
      </section>

      {/* Features Grid */}
      <section className="grid md:grid-cols-3 gap-8">
        <div className="p-8 rounded-2xl bg-zinc-900/50 border border-zinc-800/50 backdrop-blur-sm">
          <div className="w-12 h-12 bg-teal-900/30 rounded-xl flex items-center justify-center mb-6 text-teal-400">
            <EyeOff className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold mb-3 text-white">Distraction-Reduced</h3>
          <p className="text-zinc-400">
            Enable Focus Mode to dim everything except the video. We hide sidebars and comments where possible.
          </p>
        </div>
        
        <div className="p-8 rounded-2xl bg-zinc-900/50 border border-zinc-800/50 backdrop-blur-sm">
          <div className="w-12 h-12 bg-purple-900/30 rounded-xl flex items-center justify-center mb-6 text-purple-400">
            <LayoutTemplate className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold mb-3 text-white">Custom Skips</h3>
          <p className="text-zinc-400">
            Manually mark segments to automatically mute or skip. Great for skipping intro sequences or sponsor blocks.
          </p>
        </div>

        <div className="p-8 rounded-2xl bg-zinc-900/50 border border-zinc-800/50 backdrop-blur-sm">
          <div className="w-12 h-12 bg-blue-900/30 rounded-xl flex items-center justify-center mb-6 text-blue-400">
            <Shield className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold mb-3 text-white">Safe & Legal</h3>
          <p className="text-zinc-400">
            We use official embed APIs only. No hacking, no bypassing DRM. We respect platform terms and creator rights.
          </p>
        </div>
      </section>

      {/* Donation Section */}
      <section className="max-w-2xl mx-auto text-center space-y-8 py-10">
        <div className="p-8 rounded-2xl bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 shadow-xl">
          <h2 className="text-3xl font-bold text-white mb-4">Support the Project</h2>
          <p className="text-zinc-400 mb-8">
            If you find this tool useful, consider supporting the development.
          </p>
          
          <div className="flex flex-col items-center gap-4 bg-zinc-900/50 p-6 rounded-xl border border-zinc-800/50">
            <span className="text-zinc-300 font-medium">Donate via Payoneer</span>
            <div className="flex items-center gap-3 bg-white/5 px-4 py-2 rounded-lg border border-white/10">
              <span className="text-teal-400 font-mono text-lg">mumanatul@gmail.com</span>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText('mumanatul@gmail.com');
                  alert('Email copied to clipboard!');
                }}
                className="text-xs bg-zinc-800 hover:bg-zinc-700 text-white px-2 py-1 rounded transition-colors"
              >
                Copy
              </button>
            </div>
            <p className="text-xs text-zinc-500 mt-2">
              Send payments directly to this Payoneer email address.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
