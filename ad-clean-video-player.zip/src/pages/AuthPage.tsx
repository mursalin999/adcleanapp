import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Mail, Lock, User, AlertCircle, CheckCircle } from 'lucide-react';
import { useAuthStore } from '../store';

export function AuthPage() {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();
  const { login, register, isAuthenticated } = useAuthStore();

  if (isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <CheckCircle className="mb-4 h-12 w-12 text-green-400" />
        <h2 className="mb-2 text-2xl font-bold">You're Signed In</h2>
        <p className="mb-6 text-gray-400">You're already logged in.</p>
        <div className="flex gap-3">
          <button
            onClick={() => navigate('/player')}
            className="rounded-xl bg-primary px-6 py-3 font-semibold text-white hover:bg-primary-dark"
          >
            Go to Player
          </button>
          <button
            onClick={() => navigate('/settings')}
            className="rounded-xl border border-surface-lighter px-6 py-3 font-semibold text-gray-400 hover:bg-surface-lighter"
          >
            Settings
          </button>
        </div>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    if (mode === 'register') {
      if (!name) {
        setError('Please enter your name');
        return;
      }
      if (password.length < 6) {
        setError('Password must be at least 6 characters');
        return;
      }
      const ok = register(email, password, name);
      if (ok) {
        setSuccess('Account created successfully!');
        setTimeout(() => navigate('/player'), 1000);
      } else {
        setError('An account with this email already exists');
      }
    } else {
      const ok = login(email, password);
      if (ok) {
        setSuccess('Welcome back!');
        setTimeout(() => navigate('/player'), 1000);
      } else {
        setError('Invalid email or password');
      }
    }
  };

  return (
    <div className="flex items-center justify-center py-12">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary shadow-lg shadow-primary/25">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold">
            {mode === 'login' ? 'Welcome Back' : 'Create Account'}
          </h1>
          <p className="mt-1 text-sm text-gray-400">
            {mode === 'login'
              ? 'Sign in to access your saved videos and preferences'
              : 'Join AdClean Player to save videos and preferences'}
          </p>
        </div>

        <div className="rounded-2xl border border-surface-lighter bg-surface-light p-8">
          {/* Mode Toggle */}
          <div className="mb-6 flex rounded-xl bg-surface p-1">
            <button
              onClick={() => { setMode('login'); setError(''); setSuccess(''); }}
              className={`flex-1 rounded-lg py-2 text-sm font-medium transition ${
                mode === 'login' ? 'bg-primary text-white' : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => { setMode('register'); setError(''); setSuccess(''); }}
              className={`flex-1 rounded-lg py-2 text-sm font-medium transition ${
                mode === 'register' ? 'bg-primary text-white' : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              Register
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="mb-1 block text-xs font-medium text-gray-400">Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-600" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your name"
                    className="w-full rounded-xl border border-surface-lighter bg-surface py-3 pl-11 pr-4 text-white placeholder-gray-600 outline-none focus:border-primary focus:ring-2 focus:ring-primary/30"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="mb-1 block text-xs font-medium text-gray-400">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-600" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full rounded-xl border border-surface-lighter bg-surface py-3 pl-11 pr-4 text-white placeholder-gray-600 outline-none focus:border-primary focus:ring-2 focus:ring-primary/30"
                />
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs font-medium text-gray-400">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-600" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-xl border border-surface-lighter bg-surface py-3 pl-11 pr-4 text-white placeholder-gray-600 outline-none focus:border-primary focus:ring-2 focus:ring-primary/30"
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 rounded-lg bg-red-500/10 p-3 text-sm text-red-400">
                <AlertCircle className="h-4 w-4 shrink-0" />
                {error}
              </div>
            )}

            {success && (
              <div className="flex items-center gap-2 rounded-lg bg-green-500/10 p-3 text-sm text-green-400">
                <CheckCircle className="h-4 w-4 shrink-0" />
                {success}
              </div>
            )}

            <button
              type="submit"
              className="w-full rounded-xl bg-primary py-3 font-semibold text-white shadow-lg shadow-primary/25 transition hover:bg-primary-dark"
            >
              {mode === 'login' ? 'Sign In' : 'Create Account'}
            </button>
          </form>
        </div>

        <p className="mt-6 text-center text-xs text-gray-600">
          By signing in, you agree that AdClean Player stores your preferences and video data locally.
        </p>
      </div>
    </div>
  );
}
