# 🛡️ AdClean Player

**Watch social media videos with fewer distractions.**

AdClean Player is a modern web application that helps users watch social media videos in a clean, distraction-reduced environment using only legal, allowed methods. No hacking, no DRM bypass.

> **Created by Ibrahim Mursalin**

---

## ✨ Features

- 🎬 **Multi-Platform Support** – YouTube, Vimeo, Facebook, TikTok (via official embeds)
- 🌑 **Dark Mode** – Beautiful dark-first UI design
- 🔍 **Focus Mode** – Dims everything except the video player
- 🔇 **Ad Segment Control** – Mark and auto-skip/mute sponsored sections
- 💾 **Save Videos** – Save videos with custom skip/mute segments and notes
- 👤 **User Accounts** – Register/login to persist preferences
- 📱 **Fully Responsive** – Works on desktop, tablet, and mobile
- ⚖️ **100% Legal** – Uses only official embed APIs, no ToS violations

---

## 🚀 Deploy to Vercel (Step-by-Step)

### Step 1: Create a GitHub Repository

1. Go to [github.com/new](https://github.com/new)
2. Fill in the details:
   - **Repository name:** `adclean-player`
   - **Description:** `Watch social media videos with fewer distractions`
   - **Visibility:** Public (or Private, your choice)
3. **DO NOT** initialize with README, .gitignore, or license (you already have files)
4. Click **"Create repository"**

### Step 2: Push Code to GitHub

Open your terminal in the project folder and run these commands:

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Create the first commit
git commit -m "🚀 Initial commit - AdClean Player"

# Set the main branch
git branch -M main

# Add your GitHub repository as remote (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/adclean-player.git

# Push the code
git push -u origin main
```

### Step 3: Deploy to Vercel

1. Go to [vercel.com](https://vercel.com) and sign in with your GitHub account
2. Click **"Add New..."** → **"Project"**
3. Find and select your **`adclean-player`** repository from the list
4. Vercel will auto-detect the framework. Verify these settings:
   - **Framework Preset:** `Vite`
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
   - **Install Command:** `npm install`
5. Click **"Deploy"**
6. Wait 1-2 minutes for the build to complete
7. 🎉 Your app is live! Vercel will give you a URL like `https://adclean-player.vercel.app`

### Step 4: Custom Domain (Optional)

1. In your Vercel project dashboard, go to **Settings** → **Domains**
2. Add your custom domain (e.g., `adclean.yourdomain.com`)
3. Follow Vercel's DNS configuration instructions

---

## 🛠️ Run Locally

### Prerequisites

- [Node.js](https://nodejs.org/) v18 or higher
- npm (comes with Node.js)

### Setup

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/adclean-player.git
cd adclean-player

# Install dependencies
npm install

# Start the development server
npm run dev
```

The app will be running at `http://localhost:5173`

### Build for Production

```bash
npm run build
```

The built files will be in the `dist/` folder.

### Preview Production Build

```bash
npm run preview
```

---

## 📁 Project Structure

```
adclean-player/
├── index.html              # HTML entry point with meta tags
├── vercel.json             # Vercel SPA routing configuration
├── package.json            # Dependencies and scripts
├── vite.config.ts          # Vite build configuration
├── tsconfig.json           # TypeScript configuration
├── README.md               # This file
└── src/
    ├── main.tsx            # React entry point
    ├── App.tsx             # Router and page routes
    ├── index.css           # Tailwind CSS + custom styles
    ├── types.ts            # TypeScript type definitions
    ├── store.ts            # Zustand state management
    ├── utils/
    │   ├── cn.ts           # Tailwind merge utility
    │   └── platform.ts     # Platform detection & embed URL generation
    ├── components/
    │   └── Layout.tsx      # Shared layout with nav & footer
    └── pages/
        ├── LandingPage.tsx # Hero, features, how it works
        ├── PlayerPage.tsx  # Video player with controls
        ├── MyVideosPage.tsx# Saved videos list
        ├── AuthPage.tsx    # Login / Register
        └── SettingsPage.tsx# User preferences
```

---

## 🔧 Tech Stack

| Technology | Purpose |
|---|---|
| **React 19** | UI framework |
| **Vite 7** | Build tool & dev server |
| **Tailwind CSS 4** | Styling |
| **TypeScript** | Type safety |
| **Zustand** | State management |
| **React Router 7** | Client-side routing |
| **Lucide React** | Icon library |
| **localStorage** | Data persistence |

---

## 💰 Support

If AdClean Player helps you enjoy a cleaner video experience, consider supporting the project:

**[Donate via Payoneer](https://www.payoneer.com/payouts/pay/?email=mumanatul@gmail.com)**

---

## ⚖️ Legal Disclaimer

AdClean Player aims to reduce distractions while watching videos using only legal, allowed methods. It does not hack or bypass advertising systems or DRM. Users are responsible for respecting the terms of service of each platform they use.

- ✅ Uses official embed codes and APIs
- ✅ Uses only standard browser/player controls (seek, mute, pause)
- ✅ Respects copyright and platform Terms of Service
- ❌ Does NOT break or bypass DRM
- ❌ Does NOT hack or manipulate streaming protocols
- ❌ Does NOT violate any platform's Terms of Service

---

## 📄 License

MIT License – Created by **Ibrahim Mursalin**

---

## 🔄 Updating After Deployment

After making changes to your code:

```bash
# Stage your changes
git add .

# Commit with a message
git commit -m "✨ describe your changes"

# Push to GitHub
git push
```

Vercel will **automatically redeploy** whenever you push to the `main` branch. No manual action needed!
