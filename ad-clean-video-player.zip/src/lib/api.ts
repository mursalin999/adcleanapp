import { Video, VideoSegment } from './types';

// Mock Data Persistence Keys
const USERS_KEY = 'adclean_users';
const VIDEOS_KEY = 'adclean_videos';
const CURR_USER_KEY = 'adclean_current_user';

// Helper to simulate network delay
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

// --- Mock Database Access ---

function getUsers(): any[] {
  const s = localStorage.getItem(USERS_KEY);
  return s ? JSON.parse(s) : [];
}

function saveUser(user: any) {
  const users = getUsers();
  users.push(user);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getVideos(userId: number): Video[] {
  const s = localStorage.getItem(VIDEOS_KEY);
  const all: Video[] = s ? JSON.parse(s) : [];
  return all.filter(v => v.user_id === userId);
}

function saveVideo(video: Video) {
  const s = localStorage.getItem(VIDEOS_KEY);
  const all: Video[] = s ? JSON.parse(s) : [];
  all.push(video);
  localStorage.setItem(VIDEOS_KEY, JSON.stringify(all));
}

function updateVideoInDb(video: Video) {
  const s = localStorage.getItem(VIDEOS_KEY);
  let all: Video[] = s ? JSON.parse(s) : [];
  all = all.map(v => v.id === video.id ? video : v);
  localStorage.setItem(VIDEOS_KEY, JSON.stringify(all));
}

function deleteVideoInDb(id: number) {
  const s = localStorage.getItem(VIDEOS_KEY);
  let all: Video[] = s ? JSON.parse(s) : [];
  all = all.filter(v => v.id !== id);
  localStorage.setItem(VIDEOS_KEY, JSON.stringify(all));
}

// --- API Methods ---

export const api = {
  auth: {
    async register(email: string, password: string, name?: string) {
      await delay(500);
      const users = getUsers();
      if (users.find(u => u.email === email)) {
        throw new Error('Email already exists');
      }
      const newUser = {
        id: Date.now(),
        email,
        password, // In real app, hash this!
        name: name || email.split('@')[0],
        preferences: {}
      };
      saveUser(newUser);
      const { password: _, ...safeUser } = newUser;
      localStorage.setItem(CURR_USER_KEY, JSON.stringify(safeUser));
      return { user: safeUser, token: 'mock-token' };
    },

    async login(email: string, password: string) {
      await delay(500);
      const users = getUsers();
      const user = users.find(u => u.email === email && u.password === password);
      if (!user) throw new Error('Invalid credentials');
      
      const { password: _, ...safeUser } = user;
      localStorage.setItem(CURR_USER_KEY, JSON.stringify(safeUser));
      return { user: safeUser, token: 'mock-token' };
    },

    async logout() {
      localStorage.removeItem(CURR_USER_KEY);
    },

    getCurrentUser() {
      const s = localStorage.getItem(CURR_USER_KEY);
      return s ? JSON.parse(s) : null;
    }
  },

  videos: {
    async list() {
      await delay(300);
      const user = api.auth.getCurrentUser();
      if (!user) throw new Error('Not authenticated');
      return getVideos(user.id);
    },

    async create(platform: string, url: string, title: string, thumbnail: string) {
      await delay(300);
      const user = api.auth.getCurrentUser();
      if (!user) throw new Error('Not authenticated');
      
      const newVideo: Video = {
        id: Date.now(),
        user_id: user.id,
        platform,
        url,
        title,
        thumbnail,
        segments: [],
        notes: '',
        created_at: new Date().toISOString()
      };
      saveVideo(newVideo);
      return newVideo;
    },

    async update(id: number, segments: VideoSegment[], notes: string) {
      await delay(300);
      const user = api.auth.getCurrentUser();
      if (!user) throw new Error('Not authenticated');
      
      const allVideos = getVideos(user.id);
      const video = allVideos.find(v => v.id === id);
      if (!video) throw new Error('Video not found');

      video.segments = segments;
      video.notes = notes;
      updateVideoInDb(video);
      return video;
    },

    async delete(id: number) {
      await delay(300);
      deleteVideoInDb(id);
    }
  }
};
