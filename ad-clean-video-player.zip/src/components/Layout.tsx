import { Navbar } from './Navbar';

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-teal-500/30">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        {children}
      </main>
      <footer className="border-t border-zinc-900 mt-20 py-8 bg-zinc-950">
        <div className="container mx-auto px-4 text-center text-zinc-600 text-sm">
          <p className="mb-2">AdClean Player &copy; {new Date().getFullYear()} | Created by Ibrahim Mursalin</p>
          <p className="max-w-2xl mx-auto">
            AdClean Player aims to reduce distractions while watching videos using only legal, allowed methods. 
            It does not hack or bypass advertising systems or DRM. Users are responsible for respecting the terms of service of each platform they use.
          </p>
        </div>
      </footer>
    </div>
  );
}
