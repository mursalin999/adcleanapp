import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Shield, Play, Eye, Moon, Scissors, ChevronRight, ExternalLink, Sparkles, Heart } from 'lucide-react';
import { isValidUrl } from '../utils/platform';

export function LandingPage() {
  const [url, setUrl] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) {
      setError('Please paste a video URL');
      return;
    }
    if (!isValidUrl(url.trim())) {
      setError('Please enter a valid URL');
      return;
    }
    setError('');
    navigate(`/player?url=${encodeURIComponent(url.trim())}`);
  };

  const features = [
    {
      icon: Eye,
      title: 'Distraction-Reduced Viewing',
      desc: 'Focus mode dims everything except the video. Clean, minimal interface keeps your attention on content.',
    },
    {
      icon: Play,
      title: 'Multi-Platform Support',
      desc: 'Works with YouTube, Vimeo, Facebook, and TikTok using official embed APIs. More platforms coming.',
    },
    {
      icon: Moon,
      title: 'Dark Mode & Focus Mode',
      desc: 'Beautiful dark-first design with a dedicated focus mode that blocks out all visual noise.',
    },
    {
      icon: Scissors,
      title: 'User-Defined Skip Segments',
      desc: 'Mark ad segments or sponsored sections and auto-skip or auto-mute them on replay.',
    },
  ];

  const steps = [
    {
      num: '01',
      title: 'Paste your video link',
      desc: 'Copy any video URL from YouTube, Vimeo, Facebook, or TikTok.',
    },
    {
      num: '02',
      title: 'AdClean loads it cleanly',
      desc: 'We use official embeds and APIs — no hacks, no DRM bypass.',
    },
    {
      num: '03',
      title: 'Watch distraction-free',
      desc: 'Enable focus mode, mark ad segments, and enjoy the content.',
    },
  ];

  return (
    <div className="min-h-screen bg-surface text-white">
      {/* Nav */}
      <header className="relative z-10 border-b border-surface-lighter/50">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary shadow-lg shadow-primary/25">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold">AdClean Player</span>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/auth"
              className="rounded-lg px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors"
            >
              Sign In
            </Link>
            <Link
              to="/player"
              className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-white hover:bg-primary-dark transition-colors"
            >
              Open Player
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
        <div className="absolute top-20 left-1/4 h-72 w-72 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute top-40 right-1/4 h-56 w-56 rounded-full bg-accent/10 blur-3xl" />

        <div className="relative mx-auto max-w-4xl px-6 pb-20 pt-20 text-center md:pt-32">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm text-primary-light">
            <Sparkles className="h-4 w-4" />
            100% Legal & ToS Compliant
          </div>

          <h1 className="mb-6 text-4xl font-extrabold leading-tight tracking-tight md:text-6xl lg:text-7xl">
            Watch videos with
            <span className="bg-gradient-to-r from-primary to-primary-light bg-clip-text text-transparent">
              {' '}fewer distractions
            </span>
          </h1>

          <p className="mx-auto mb-10 max-w-2xl text-lg text-gray-400 md:text-xl">
            AdClean Player uses official embed APIs and browser features to reduce visual clutter around
            social media videos. No hacking. No DRM bypass. Just cleaner viewing.
          </p>

          {/* URL Input */}
          <form onSubmit={handleSubmit} className="mx-auto max-w-2xl">
            <div className="flex flex-col gap-3 sm:flex-row">
              <div className="relative flex-1">
                <ExternalLink className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-500" />
                <input
                  type="text"
                  value={url}
                  onChange={(e) => { setUrl(e.target.value); setError(''); }}
                  placeholder="Paste a YouTube, Vimeo, Facebook, or TikTok link..."
                  className="w-full rounded-xl border border-surface-lighter bg-surface-light py-4 pl-12 pr-4 text-white placeholder-gray-500 outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/30"
                />
              </div>
              <button
                type="submit"
                className="flex items-center justify-center gap-2 rounded-xl bg-primary px-8 py-4 font-semibold text-white shadow-lg shadow-primary/25 transition-all hover:bg-primary-dark hover:shadow-primary/40 active:scale-[0.98]"
              >
                <Play className="h-5 w-5" />
                Watch Now
              </button>
            </div>
            {error && <p className="mt-2 text-left text-sm text-red-400">{error}</p>}
          </form>

          <p className="mt-4 text-sm text-gray-600">
            Try: https://www.youtube.com/watch?v=dQw4w9WgXcQ
          </p>
        </div>
      </section>

      {/* How It Works */}
      <section className="border-t border-surface-lighter bg-surface-light/50 py-20">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="mb-4 text-center text-3xl font-bold md:text-4xl">How It Works</h2>
          <p className="mb-14 text-center text-gray-400">Three simple steps to cleaner video watching</p>

          <div className="grid gap-8 md:grid-cols-3">
            {steps.map((step, i) => (
              <div key={i} className="group relative rounded-2xl border border-surface-lighter bg-surface p-8 transition-all hover:border-primary/40">
                <div className="mb-4 text-4xl font-black text-primary/30">{step.num}</div>
                <h3 className="mb-2 text-lg font-semibold text-white">{step.title}</h3>
                <p className="text-sm text-gray-400">{step.desc}</p>
                {i < 2 && (
                  <ChevronRight className="absolute right-[-20px] top-1/2 hidden h-6 w-6 -translate-y-1/2 text-surface-lighter md:block" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="mb-4 text-center text-3xl font-bold md:text-4xl">Key Features</h2>
          <p className="mb-14 text-center text-gray-400">Designed to help you focus on what matters</p>

          <div className="grid gap-6 sm:grid-cols-2">
            {features.map((f, i) => {
              const Icon = f.icon;
              return (
                <div
                  key={i}
                  className="rounded-2xl border border-surface-lighter bg-surface-light p-8 transition-all hover:border-primary/40"
                >
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15 text-primary">
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold text-white">{f.title}</h3>
                  <p className="text-sm leading-relaxed text-gray-400">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Legal Disclaimer */}
      <section className="border-t border-surface-lighter bg-surface-light/50 py-16">
        <div className="mx-auto max-w-4xl px-6">
          <div className="rounded-2xl border border-primary/20 bg-primary/5 p-8">
            <div className="mb-4 flex items-center gap-3">
              <Shield className="h-6 w-6 text-primary" />
              <h2 className="text-xl font-bold">Legal & Compliance</h2>
            </div>
            <div className="space-y-3 text-sm leading-relaxed text-gray-400">
              <p>
                <strong className="text-gray-300">We do NOT hack or bypass platform protections.</strong>{' '}
                AdClean Player uses only official embed codes, official APIs, and standard browser
                capabilities.
              </p>
              <p>
                <strong className="text-gray-300">We respect copyright and platform Terms of Service.</strong>{' '}
                Videos are loaded through their platform's official embed player. We never download,
                re-host, or modify video streams.
              </p>
              <p>
                <strong className="text-gray-300">Ad reduction features are user-controlled.</strong>{' '}
                Our skip/mute tools use standard player controls (seek, mute). Users manually mark
                segments based on their own viewing preferences.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Donate Section */}
      <section className="border-t border-surface-lighter bg-surface py-16">
        <div className="mx-auto max-w-2xl px-6 text-center">
          <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-pink-500 to-rose-500 shadow-lg shadow-pink-500/25">
            <Heart className="h-7 w-7 text-white" />
          </div>
          <h2 className="mb-3 text-2xl font-bold">Support This Project</h2>
          <p className="mb-6 text-gray-400">
            If AdClean Player helps you enjoy a cleaner video experience, consider supporting the developer
            with a donation. Every contribution helps keep the project alive and improving!
          </p>
          <a
            href="https://www.payoneer.com/payouts/pay/?email=mumanatul@gmail.com"
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 px-8 py-4 text-lg font-bold text-white shadow-xl shadow-pink-500/25 transition-all hover:shadow-pink-500/40 hover:scale-105 active:scale-100"
          >
            <Heart className="h-5 w-5 transition-transform group-hover:scale-125 group-hover:animate-pulse" />
            Donate via Payoneer
          </a>
          <p className="mt-4 text-xs text-gray-600">
            Secure payment processed through Payoneer
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-surface-lighter px-6 py-8">
        <div className="mx-auto max-w-6xl">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <span className="font-semibold">AdClean Player</span>
            </div>
            <a
              href="https://www.payoneer.com/payouts/pay/?email=mumanatul@gmail.com"
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-pink-500 to-rose-500 px-5 py-2 text-sm font-semibold text-white shadow-md shadow-pink-500/20 transition-all hover:shadow-pink-500/40 hover:scale-105"
            >
              <Heart className="h-4 w-4 group-hover:scale-110 transition-transform" />
              Donate
            </a>
            <p className="max-w-md text-center text-xs text-gray-600 md:text-right">
              AdClean Player aims to reduce distractions while watching videos using only legal, allowed
              methods. It does not hack or bypass advertising systems or DRM.
            </p>
          </div>
          <div className="mt-6 border-t border-surface-lighter pt-4">
            <p className="text-center text-xs text-gray-500">
              Created by <span className="font-semibold text-gray-300">Ibrahim Mursalin</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
