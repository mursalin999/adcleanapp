import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Film, Trash2, Play, Scissors, VolumeX, Clock, AlertCircle } from 'lucide-react';
import { useAuthStore, useVideosStore } from '../store';
import { PLATFORMS, formatTime } from '../utils/platform';
import type { Platform } from '../types';

export function MyVideosPage() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuthStore();
  const { videos, loadVideos, deleteVideo } = useVideosStore();

  useEffect(() => {
    if (user) {
      loadVideos(user.id);
    }
  }, [user, loadVideos]);

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <AlertCircle className="mb-4 h-12 w-12 text-yellow-500" />
        <h2 className="mb-2 text-2xl font-bold">Sign In Required</h2>
        <p className="mb-6 text-gray-400">You need to sign in to access your saved videos.</p>
        <button
          onClick={() => navigate('/auth')}
          className="rounded-xl bg-primary px-6 py-3 font-semibold text-white hover:bg-primary-dark"
        >
          Sign In
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">My Videos</h1>
        <p className="mt-1 text-gray-400">Videos you've saved with your custom skip/mute segments</p>
      </div>

      {videos.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-surface-lighter py-20 text-center">
          <Film className="mb-4 h-16 w-16 text-surface-lighter" />
          <h3 className="mb-2 text-xl font-semibold text-gray-400">No Saved Videos</h3>
          <p className="mb-6 text-sm text-gray-600">
            Watch a video and click "Save to My Videos" to add it here.
          </p>
          <button
            onClick={() => navigate('/player')}
            className="rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-white hover:bg-primary-dark"
          >
            Open Player
          </button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {videos.map((video) => {
            const platformInfo = PLATFORMS[video.platform as Platform] || PLATFORMS.unknown;
            const skipCount = video.segments.filter(s => s.type === 'skip').length;
            const muteCount = video.segments.filter(s => s.type === 'mute').length;

            return (
              <div
                key={video.id}
                className="group rounded-2xl border border-surface-lighter bg-surface-light overflow-hidden transition hover:border-surface-lighter/80"
              >
                {/* Thumbnail */}
                <div
                  className="relative h-40 bg-surface-lighter cursor-pointer"
                  onClick={() => navigate(`/player?url=${encodeURIComponent(video.url)}`)}
                >
                  {video.thumbnail ? (
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="h-full w-full object-cover"
                      onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center">
                      <Film className="h-10 w-10 text-gray-600" />
                    </div>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 transition group-hover:opacity-100">
                    <Play className="h-10 w-10 text-white" />
                  </div>
                  <span
                    className="absolute top-2 left-2 rounded-full px-2 py-0.5 text-xs font-medium"
                    style={{ backgroundColor: platformInfo.color + '33', color: platformInfo.color }}
                  >
                    {platformInfo.icon} {platformInfo.name}
                  </span>
                </div>

                {/* Info */}
                <div className="p-4">
                  <h3 className="mb-1 truncate text-sm font-semibold">{video.title}</h3>
                  <p className="mb-3 flex items-center gap-1 text-xs text-gray-500">
                    <Clock className="h-3 w-3" />
                    {new Date(video.dateAdded).toLocaleDateString()}
                  </p>

                  {/* Segment indicators */}
                  <div className="mb-3 flex flex-wrap gap-2">
                    {skipCount > 0 && (
                      <span className="flex items-center gap-1 rounded-full bg-red-500/10 px-2 py-0.5 text-xs text-red-400">
                        <Scissors className="h-3 w-3" />
                        {skipCount} skip{skipCount > 1 ? 's' : ''}
                      </span>
                    )}
                    {muteCount > 0 && (
                      <span className="flex items-center gap-1 rounded-full bg-yellow-500/10 px-2 py-0.5 text-xs text-yellow-400">
                        <VolumeX className="h-3 w-3" />
                        {muteCount} mute{muteCount > 1 ? 's' : ''}
                      </span>
                    )}
                    {video.segments.length === 0 && (
                      <span className="text-xs text-gray-600">No segments defined</span>
                    )}
                  </div>

                  {/* Segment details */}
                  {video.segments.length > 0 && (
                    <div className="mb-3 space-y-1">
                      {video.segments.slice(0, 3).map((seg) => (
                        <div key={seg.id} className="flex items-center gap-2 text-xs text-gray-500">
                          <span className={`rounded px-1.5 py-0.5 text-[10px] font-medium ${
                            seg.type === 'skip' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'
                          }`}>
                            {seg.type.toUpperCase()}
                          </span>
                          {formatTime(seg.startTime)} → {formatTime(seg.endTime)}
                        </div>
                      ))}
                      {video.segments.length > 3 && (
                        <p className="text-xs text-gray-600">+{video.segments.length - 3} more</p>
                      )}
                    </div>
                  )}

                  {/* Notes preview */}
                  {video.notes && (
                    <p className="mb-3 truncate text-xs text-gray-500 italic">"{video.notes}"</p>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate(`/player?url=${encodeURIComponent(video.url)}`)}
                      className="flex flex-1 items-center justify-center gap-1 rounded-lg bg-primary/20 py-2 text-xs font-medium text-primary-light transition hover:bg-primary/30"
                    >
                      <Play className="h-3 w-3" />
                      Watch
                    </button>
                    <button
                      onClick={() => deleteVideo(video.id)}
                      className="rounded-lg bg-surface px-3 py-2 text-xs text-gray-500 transition hover:bg-red-500/10 hover:text-red-400"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
