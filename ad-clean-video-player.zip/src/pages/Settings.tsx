import { api } from '@/lib/api';
import { useNavigate } from 'react-router-dom';

export function Settings() {
  const user = api.auth.getCurrentUser();
  const navigate = useNavigate();

  if (!user) {
    navigate('/login');
    return null;
  }

  const handleDeleteAccount = () => {
    if (confirm("Are you sure? This will delete all your data locally.")) {
      api.auth.logout();
      navigate('/');
      window.location.reload();
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <h1 className="text-3xl font-bold text-white">Settings</h1>

      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 space-y-6">
        <div>
          <h2 className="text-xl font-semibold text-white mb-4">Profile</h2>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <label className="block text-zinc-500 mb-1">Name</label>
              <div className="text-white bg-zinc-950 p-2 rounded border border-zinc-800">{user.name}</div>
            </div>
            <div>
              <label className="block text-zinc-500 mb-1">Email</label>
              <div className="text-white bg-zinc-950 p-2 rounded border border-zinc-800">{user.email}</div>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-zinc-800">
          <h2 className="text-xl font-semibold text-white mb-4">Preferences</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-zinc-300">Default to Focus Mode</span>
              <div className="w-10 h-6 bg-zinc-800 rounded-full relative cursor-not-allowed">
                <div className="absolute left-1 top-1 w-4 h-4 bg-zinc-600 rounded-full"></div>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-zinc-300">Theme</span>
              <select className="bg-zinc-950 border border-zinc-800 text-white text-sm rounded p-1">
                <option>Dark (Default)</option>
                <option>Light (Coming Soon)</option>
              </select>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-zinc-800">
          <h2 className="text-xl font-semibold text-red-400 mb-4">Danger Zone</h2>
          <button 
            onClick={handleDeleteAccount}
            className="bg-red-900/20 hover:bg-red-900/40 text-red-400 border border-red-900/50 px-4 py-2 rounded text-sm transition-colors"
          >
            Delete Account & Data
          </button>
        </div>
      </div>
    </div>
  );
}
