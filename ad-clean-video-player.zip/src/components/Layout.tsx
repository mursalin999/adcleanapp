import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuthStore } from '../store';
import { Home, Film, Settings, User, LogOut, Shield, Heart } from 'lucide-react';

export function Layout() {
  const { user, isAuthenticated, logout } = useAuthStore();
  const location = useLocation();

  const navItems = [
    { to: '/', label: 'Home', icon: Home },
    { to: '/player', label: 'Player', icon: Film },
    ...(isAuthenticated ? [{ to: '/my-videos', label: 'My Videos', icon: Film }] : []),
    { to: '/settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-surface text-white">
      {/* Top Nav */}
      <header className="sticky top-0 z-50 border-b border-surface-lighter bg-surface/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <span className="text-lg font-bold text-white">AdClean Player</span>
          </Link>

          <nav className="hidden items-center gap-1 md:flex">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.to;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-primary/20 text-primary-light'
                      : 'text-gray-400 hover:bg-surface-lighter hover:text-white'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2">
            {isAuthenticated ? (
              <div className="flex items-center gap-3">
                <Link
                  to="/settings"
                  className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-300 hover:bg-surface-lighter"
                >
                  <User className="h-4 w-4" />
                  <span className="hidden sm:inline">{user?.name}</span>
                </Link>
                <button
                  onClick={logout}
                  className="flex items-center gap-1 rounded-lg px-3 py-2 text-sm text-gray-400 hover:bg-surface-lighter hover:text-red-400"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <Link
                to="/auth"
                className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-white hover:bg-primary-dark"
              >
                Sign In
              </Link>
            )}
          </div>
        </div>

        {/* Mobile Nav */}
        <div className="flex border-t border-surface-lighter md:hidden">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex flex-1 flex-col items-center gap-1 py-2 text-xs ${
                  isActive ? 'text-primary-light' : 'text-gray-500'
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-4 py-6">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="border-t border-surface-lighter bg-surface px-4 py-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-4 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <span className="font-semibold text-white">AdClean Player</span>
            </div>
            <a
              href="https://www.payoneer.com/payouts/pay/?email=mumanatul@gmail.com"
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-pink-500/20 transition-all hover:shadow-pink-500/40 hover:scale-105 active:scale-100"
            >
              <Heart className="h-4 w-4 transition-transform group-hover:scale-125" />
              Donate via Payoneer
            </a>
          </div>
          <p className="max-w-2xl text-xs leading-relaxed text-gray-500">
            AdClean Player aims to reduce distractions while watching videos using only legal, allowed
            methods. It does not hack or bypass advertising systems or DRM. Users are responsible for
            respecting the terms of service of each platform they use.
          </p>
          <div className="mt-4 flex gap-4 text-xs text-gray-600">
            <Link to="/settings" className="hover:text-gray-400">Settings</Link>
            <Link to="/auth" className="hover:text-gray-400">Account</Link>
          </div>
          <div className="mt-6 border-t border-surface-lighter pt-4">
            <p className="text-center text-xs text-gray-500">
              Created by <span className="font-semibold text-gray-300">Ibrahim Mursalin</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
