import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User, Moon, Sun, Eye, EyeOff, VolumeX, Volume2,
  Shield, Trash2, Save, CheckCircle, AlertCircle, Settings
} from 'lucide-react';
import { useAuthStore } from '../store';

export function SettingsPage() {
  const navigate = useNavigate();
  const { user, isAuthenticated, updatePreferences, updateProfile, deleteAccount, logout } = useAuthStore();

  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [saved, setSaved] = useState(false);
  const [showDelete, setShowDelete] = useState(false);

  const prefs = user?.preferences || {
    theme: 'dark' as const,
    defaultFocusMode: false,
    defaultHideSuggestions: true,
    defaultAutoMute: true,
  };

  const handleSaveProfile = () => {
    if (!isAuthenticated) return;
    updateProfile(name, email);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleDeleteAccount = () => {
    deleteAccount();
    navigate('/');
  };

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <Settings className="mb-4 h-12 w-12 text-gray-600" />
        <h2 className="mb-2 text-2xl font-bold">Settings</h2>
        <p className="mb-6 text-gray-400">Sign in to manage your preferences and account.</p>
        <button
          onClick={() => navigate('/auth')}
          className="rounded-xl bg-primary px-6 py-3 font-semibold text-white hover:bg-primary-dark"
        >
          Sign In
        </button>

        {/* Guest preferences info */}
        <div className="mt-12 w-full max-w-lg rounded-2xl border border-surface-lighter bg-surface-light p-6 text-left">
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-gray-400">Guest Mode</h3>
          <p className="text-sm text-gray-500">
            As a guest, you can still use AdClean Player. However, your preferences and saved videos
            won't persist between sessions. Create an account to save everything.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="mt-1 text-gray-400">Manage your profile and default preferences</p>
      </div>

      {/* Profile */}
      <div className="mb-6 rounded-2xl border border-surface-lighter bg-surface-light p-6">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
          <User className="h-5 w-5 text-primary" />
          Profile
        </h2>

        <div className="space-y-4">
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-xl border border-surface-lighter bg-surface py-3 px-4 text-white outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl border border-surface-lighter bg-surface py-3 px-4 text-white outline-none focus:border-primary"
            />
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleSaveProfile}
              className={`flex items-center gap-2 rounded-xl px-6 py-2.5 text-sm font-semibold transition ${
                saved
                  ? 'bg-green-500/20 text-green-400'
                  : 'bg-primary text-white hover:bg-primary-dark'
              }`}
            >
              {saved ? <CheckCircle className="h-4 w-4" /> : <Save className="h-4 w-4" />}
              {saved ? 'Saved!' : 'Save Profile'}
            </button>
            <p className="text-xs text-gray-600">
              Member since {user && new Date(user.createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>
      </div>

      {/* Preferences */}
      <div className="mb-6 rounded-2xl border border-surface-lighter bg-surface-light p-6">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
          <Settings className="h-5 w-5 text-primary" />
          Default Preferences
        </h2>

        <div className="space-y-3">
          <div className="flex items-center justify-between rounded-xl bg-surface p-4">
            <div className="flex items-center gap-3">
              {prefs.theme === 'dark' ? <Moon className="h-5 w-5 text-primary" /> : <Sun className="h-5 w-5 text-yellow-400" />}
              <div>
                <p className="text-sm font-medium">Theme</p>
                <p className="text-xs text-gray-500">Choose dark or light mode</p>
              </div>
            </div>
            <button
              onClick={() => updatePreferences({ theme: prefs.theme === 'dark' ? 'light' : 'dark' })}
              className={`relative h-6 w-11 rounded-full transition-colors ${
                prefs.theme === 'dark' ? 'bg-primary' : 'bg-surface-lighter'
              }`}
            >
              <span
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
                  prefs.theme === 'dark' ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between rounded-xl bg-surface p-4">
            <div className="flex items-center gap-3">
              <Eye className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm font-medium">Default Focus Mode</p>
                <p className="text-xs text-gray-500">Enable focus mode by default when watching</p>
              </div>
            </div>
            <button
              onClick={() => updatePreferences({ defaultFocusMode: !prefs.defaultFocusMode })}
              className={`relative h-6 w-11 rounded-full transition-colors ${
                prefs.defaultFocusMode ? 'bg-primary' : 'bg-surface-lighter'
              }`}
            >
              <span
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
                  prefs.defaultFocusMode ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between rounded-xl bg-surface p-4">
            <div className="flex items-center gap-3">
              {prefs.defaultHideSuggestions ? <EyeOff className="h-5 w-5 text-primary" /> : <Eye className="h-5 w-5 text-gray-500" />}
              <div>
                <p className="text-sm font-medium">Default Hide Suggestions</p>
                <p className="text-xs text-gray-500">Hide recommended videos by default</p>
              </div>
            </div>
            <button
              onClick={() => updatePreferences({ defaultHideSuggestions: !prefs.defaultHideSuggestions })}
              className={`relative h-6 w-11 rounded-full transition-colors ${
                prefs.defaultHideSuggestions ? 'bg-primary' : 'bg-surface-lighter'
              }`}
            >
              <span
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
                  prefs.defaultHideSuggestions ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between rounded-xl bg-surface p-4">
            <div className="flex items-center gap-3">
              {prefs.defaultAutoMute ? <VolumeX className="h-5 w-5 text-primary" /> : <Volume2 className="h-5 w-5 text-gray-500" />}
              <div>
                <p className="text-sm font-medium">Default Auto-Mute Segments</p>
                <p className="text-xs text-gray-500">Auto-mute marked ad segments by default</p>
              </div>
            </div>
            <button
              onClick={() => updatePreferences({ defaultAutoMute: !prefs.defaultAutoMute })}
              className={`relative h-6 w-11 rounded-full transition-colors ${
                prefs.defaultAutoMute ? 'bg-primary' : 'bg-surface-lighter'
              }`}
            >
              <span
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
                  prefs.defaultAutoMute ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Privacy & Data */}
      <div className="mb-6 rounded-2xl border border-surface-lighter bg-surface-light p-6">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
          <Shield className="h-5 w-5 text-primary" />
          Privacy & Data
        </h2>

        <div className="mb-4 space-y-3 text-sm text-gray-400">
          <p>
            <strong className="text-gray-300">What we store:</strong> Your profile info, preferences,
            saved video URLs, skip/mute segment times, and notes. All data is stored locally in your browser.
          </p>
          <p>
            <strong className="text-gray-300">What we don't do:</strong> We do not track your viewing
            habits, sell your data, or communicate with any third-party analytics services.
          </p>
        </div>

        <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-4">
          <h3 className="mb-2 text-sm font-semibold text-red-400">Danger Zone</h3>
          {!showDelete ? (
            <button
              onClick={() => setShowDelete(true)}
              className="flex items-center gap-2 rounded-lg bg-red-500/20 px-4 py-2 text-sm font-medium text-red-400 transition hover:bg-red-500/30"
            >
              <Trash2 className="h-4 w-4" />
              Delete Account & All Data
            </button>
          ) : (
            <div className="space-y-3">
              <p className="flex items-start gap-2 text-sm text-red-400">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                This will permanently delete your account, preferences, and all saved videos. This cannot be undone.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={handleDeleteAccount}
                  className="rounded-lg bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-600"
                >
                  Yes, Delete Everything
                </button>
                <button
                  onClick={() => setShowDelete(false)}
                  className="rounded-lg border border-surface-lighter px-4 py-2 text-sm text-gray-400 hover:bg-surface-lighter"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Sign Out */}
      <button
        onClick={() => { logout(); navigate('/'); }}
        className="w-full rounded-xl border border-surface-lighter py-3 text-sm font-medium text-gray-400 transition hover:bg-surface-lighter hover:text-white"
      >
        Sign Out
      </button>
    </div>
  );
}
