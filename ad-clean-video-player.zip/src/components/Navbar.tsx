import { Link, useNavigate } from 'react-router-dom';
import { api } from '@/lib/api';
import { LogOut, MonitorPlay } from 'lucide-react';

export function Navbar() {
  const user = api.auth.getCurrentUser();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await api.auth.logout();
    navigate('/');
    window.location.reload(); // Simple reload to clear state
  };

  return (
    <nav className="border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 text-teal-400 hover:text-teal-300 transition-colors">
          <MonitorPlay className="w-6 h-6" />
          <span className="font-bold text-xl tracking-tight">AdClean Player</span>
        </Link>

        <div className="flex items-center gap-6">
          <Link to="/" className="text-zinc-400 hover:text-white text-sm font-medium">
            Home
          </Link>
          
          {user ? (
            <>
              <Link to="/dashboard" className="text-zinc-400 hover:text-white text-sm font-medium">
                My Videos
              </Link>
              <div className="flex items-center gap-4 pl-4 border-l border-zinc-800">
                <span className="text-zinc-500 text-sm hidden sm:inline-block">{user.name}</span>
                <button 
                  onClick={handleLogout}
                  className="p-2 text-zinc-400 hover:text-red-400 transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-4">
              <Link to="/login" className="text-zinc-400 hover:text-white text-sm font-medium">
                Login
              </Link>
              <Link 
                to="/register" 
                className="bg-teal-600 hover:bg-teal-500 text-white px-4 py-2 rounded-full text-sm font-medium transition-colors"
              >
                Sign Up
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
