import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '@/lib/api';
import { Video } from '@/lib/types';
import { Trash2, PlayCircle, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export function Dashboard() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadVideos();
  }, []);

  const loadVideos = async () => {
    try {
      const data = await api.videos.list();
      setVideos(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to remove this video from your history?')) return;
    try {
      await api.videos.delete(id);
      setVideos(videos.filter(v => v.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return <div className="text-center py-20 text-zinc-500">Loading your videos...</div>;
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-white">My Videos</h1>
        <Link to="/" className="bg-zinc-800 hover:bg-zinc-700 text-white px-4 py-2 rounded-lg text-sm transition-colors">
          + Add New
        </Link>
      </div>

      {videos.length === 0 ? (
        <div className="text-center py-20 bg-zinc-900/50 rounded-2xl border border-zinc-800 border-dashed">
          <p className="text-zinc-500 mb-4">You haven't saved any videos yet.</p>
          <Link to="/" className="text-teal-400 hover:text-teal-300">
            Go to Home to start watching
          </Link>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videos.map(video => (
            <div key={video.id} className="group bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden hover:border-teal-500/30 transition-all">
              <div className="aspect-video bg-zinc-950 relative overflow-hidden">
                {video.thumbnail ? (
                  <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-zinc-700">
                    <PlayCircle className="w-12 h-12" />
                  </div>
                )}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                  <Link to={`/player?id=${video.id}`} className="bg-teal-600 text-white p-3 rounded-full hover:bg-teal-500 transform scale-90 group-hover:scale-100 transition-all">
                    <PlayCircle className="w-8 h-8" />
                  </Link>
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="font-semibold text-white truncate mb-1" title={video.title}>{video.title || 'Untitled Video'}</h3>
                <div className="flex items-center justify-between text-xs text-zinc-500 mt-2">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {video.created_at ? formatDistanceToNow(new Date(video.created_at), { addSuffix: true }) : 'Recently'}
                  </span>
                  <div className="flex items-center gap-3">
                    <span className="bg-zinc-800 px-2 py-0.5 rounded text-zinc-400">
                      {video.segments.length} skips
                    </span>
                    <button 
                      onClick={() => handleDelete(video.id)}
                      className="text-zinc-500 hover:text-red-400 transition-colors"
                      title="Remove"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
