import type { Platform, PlatformInfo } from '../types';

export const PLATFORMS: Record<Platform, PlatformInfo> = {
  youtube: { name: 'YouTube', icon: '▶', color: '#FF0000', supported: true },
  vimeo: { name: 'Vimeo', icon: '▷', color: '#1AB7EA', supported: true },
  facebook: { name: 'Facebook', icon: 'f', color: '#1877F2', supported: true },
  instagram: { name: 'Instagram', icon: '📷', color: '#E4405F', supported: false },
  tiktok: { name: 'TikTok', icon: '♪', color: '#000000', supported: true },
  twitter: { name: 'X / Twitter', icon: '𝕏', color: '#1DA1F2', supported: false },
  unknown: { name: 'Unknown', icon: '?', color: '#666', supported: false },
};

export function detectPlatform(url: string): Platform {
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    if (host.includes('youtube.com') || host.includes('youtu.be')) return 'youtube';
    if (host.includes('vimeo.com')) return 'vimeo';
    if (host.includes('facebook.com') || host.includes('fb.watch')) return 'facebook';
    if (host.includes('instagram.com')) return 'instagram';
    if (host.includes('tiktok.com')) return 'tiktok';
    if (host.includes('twitter.com') || host.includes('x.com')) return 'twitter';
    return 'unknown';
  } catch {
    return 'unknown';
  }
}

export function getYouTubeId(url: string): string | null {
  try {
    const u = new URL(url);
    if (u.hostname.includes('youtu.be')) {
      return u.pathname.slice(1);
    }
    if (u.hostname.includes('youtube.com')) {
      if (u.pathname.includes('/shorts/')) {
        return u.pathname.split('/shorts/')[1]?.split('/')[0] || null;
      }
      return u.searchParams.get('v');
    }
    return null;
  } catch {
    return null;
  }
}

export function getVimeoId(url: string): string | null {
  try {
    const u = new URL(url);
    const match = u.pathname.match(/\/(\d+)/);
    return match ? match[1] : null;
  } catch {
    return null;
  }
}

export function getFacebookVideoUrl(url: string): string | null {
  try {
    new URL(url);
    return encodeURIComponent(url);
  } catch {
    return null;
  }
}

export function getTikTokEmbedUrl(url: string): string | null {
  try {
    const u = new URL(url);
    const match = u.pathname.match(/\/video\/(\d+)/);
    if (match) return match[1];
    // For short URLs, return the full URL
    return null;
  } catch {
    return null;
  }
}

export function getEmbedUrl(url: string, platform: Platform, hideSuggestions: boolean): string | null {
  switch (platform) {
    case 'youtube': {
      const id = getYouTubeId(url);
      if (!id) return null;
      const params = new URLSearchParams({
        rel: hideSuggestions ? '0' : '1',
        modestbranding: '1',
        iv_load_policy: '3',
      });
      return `https://www.youtube.com/embed/${id}?${params.toString()}`;
    }
    case 'vimeo': {
      const id = getVimeoId(url);
      if (!id) return null;
      return `https://player.vimeo.com/video/${id}?title=0&byline=0&portrait=0`;
    }
    case 'facebook': {
      const encoded = getFacebookVideoUrl(url);
      if (!encoded) return null;
      return `https://www.facebook.com/plugins/video.php?href=${encoded}&show_text=false&width=720`;
    }
    case 'tiktok': {
      const videoId = getTikTokEmbedUrl(url);
      if (!videoId) return null;
      return `https://www.tiktok.com/embed/v2/${videoId}`;
    }
    default:
      return null;
  }
}

export function getVideoTitle(_url: string, platform: Platform): string {
  const info = PLATFORMS[platform];
  if (!info.supported) return 'Unsupported Platform';
  return `${info.name} Video`;
}

export function getVideoThumbnail(url: string, platform: Platform): string {
  if (platform === 'youtube') {
    const id = getYouTubeId(url);
    if (id) return `https://img.youtube.com/vi/${id}/mqdefault.jpg`;
  }
  return '';
}

export function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

export function parseTime(str: string): number {
  const parts = str.split(':').map(Number);
  if (parts.length === 2) return (parts[0] || 0) * 60 + (parts[1] || 0);
  if (parts.length === 3) return (parts[0] || 0) * 3600 + (parts[1] || 0) * 60 + (parts[2] || 0);
  return 0;
}

export function isValidUrl(str: string): boolean {
  try {
    new URL(str);
    return true;
  } catch {
    return false;
  }
}
