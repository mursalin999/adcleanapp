import { Navigate } from 'react-router-dom';
import { api } from '@/lib/api';

export function PrivateRoute({ children }: { children: React.ReactNode }) {
  const user = api.auth.getCurrentUser();
  return user ? <>{children}</> : <Navigate to="/login" replace />;
}
