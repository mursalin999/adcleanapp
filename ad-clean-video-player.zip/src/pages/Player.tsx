import { useState, useRef, useEffect, useCallback } from 'react';
import ReactPlayer from 'react-player';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { api } from '@/lib/api';
import { Video, VideoSegment } from '@/lib/types';
import { 
  Minimize2, VolumeX, 
  SkipForward, Plus, Save, Eye
} from 'lucide-react';
import { cn } from '@/utils/cn'; 

export function Player() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const playerRef = useRef<any>(null);
  const RP = ReactPlayer as any;
  
  // State
  const [url, setUrl] = useState<string>('');
  const [videoData, setVideoData] = useState<Video | null>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  
  // Features
  const [focusMode, setFocusMode] = useState(false);
  const [segments, setSegments] = useState<VideoSegment[]>([]);
  const [notes, setNotes] = useState('');
  
  // New Segment Inputs
  const [newSegStart, setNewSegStart] = useState('');
  const [newSegEnd, setNewSegEnd] = useState('');
  const [newSegType, setNewSegType] = useState<'skip' | 'mute'>('skip');

  // Load Video Logic
  useEffect(() => {
    const idParam = searchParams.get('id');
    const urlParam = searchParams.get('url');

    const load = async () => {
      if (idParam) {
        try {
          // If we have an ID, we try to fetch from user's list
          // But first we need to be logged in. If not, maybe just error or redirect.
          // For now assuming logged in or it fails gracefully.
          const user = api.auth.getCurrentUser();
          if (user) {
             const list = await api.videos.list();
             const found = list.find(v => v.id === parseInt(idParam));
             if (found) {
               setVideoData(found);
               setUrl(found.url);
               setSegments(found.segments || []);
               setNotes(found.notes || '');
             }
          }
        } catch (e) {
          console.error("Failed to load video", e);
        }
      } else if (urlParam) {
        setUrl(urlParam);
        // Try to find if we already saved this URL? 
        // For simplicity, treat as new unsaved video.
      }
    };
    load();
  }, [searchParams]);

  // Watch Progress for Skips/Mutes
  const handleProgress = useCallback((state: { playedSeconds: number }) => {
    const curr = state.playedSeconds;
    setCurrentTime(curr);

    // Check segments
    const activeSegment = segments.find(s => curr >= s.start && curr < s.end);
    
    if (activeSegment) {
      if (activeSegment.type === 'skip') {
        // seek to end
        playerRef.current?.seekTo(activeSegment.end, 'seconds');
        // show toast or visual indicator?
      } else if (activeSegment.type === 'mute') {
        if (!muted) setMuted(true);
      }
    } else {
      // If we were muting because of a segment, unmute
      // We need to know if we are "in" a mute segment. 
      // If no active segment is mute type, make sure we restore volume IF we auto-muted.
      // This is tricky without "wasAutoMuted" state. 
      // Simplified: If muted is true, check if we just left a mute segment.
      // For this demo, let's just leave it manual unmute or simple toggle.
      // actually, let's try to be smart:
      // if (muted && !activeSegment) setMuted(false); // This would annoy users who manually muted.
    }
  }, [segments, muted]);

  // Handle Adding Segment
  const addSegment = () => {
    const start = parseFloat(newSegStart);
    const end = parseFloat(newSegEnd);
    
    if (isNaN(start) || isNaN(end) || start >= end) {
      alert('Invalid time range');
      return;
    }

    const newSeg: VideoSegment = {
      id: Date.now().toString(),
      start,
      end,
      type: newSegType
    };
    
    const newSegments = [...segments, newSeg].sort((a, b) => a.start - b.start);
    setSegments(newSegments);
    setNewSegStart('');
    setNewSegEnd('');
  };

  const removeSegment = (id: string) => {
    setSegments(segments.filter(s => s.id !== id));
  };

  const handleSave = async () => {
    const user = api.auth.getCurrentUser();
    if (!user) {
      if(confirm("You need to log in to save videos. Go to login?")) {
        navigate('/login');
      }
      return;
    }

    try {
      if (videoData) {
        // Update
        const updated = await api.videos.update(videoData.id, segments, notes);
        setVideoData(updated);
        alert('Saved successfully!');
      } else {
        // Create
        // We need metadata. ReactPlayer doesn't give title easily without playing.
        // We'll use a placeholder or prompt.
        const title = prompt("Enter a title for this video:", "My Video");
        if (!title) return;
        
        const newVideo = await api.videos.create('web', url, title, '');
        // Then update with segments
        await api.videos.update(newVideo.id, segments, notes);
        setVideoData(newVideo);
        navigate(`?id=${newVideo.id}`, { replace: true }); // Update URL
        alert('Saved to My Videos!');
      }
    } catch (e) {
      console.error(e);
      alert('Failed to save');
    }
  };

  const formatTime = (seconds: number) => {
    const pad = (n: number) => n.toString().padStart(2, '0');
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${pad(m)}:${pad(s)}`;
  };

  const setStartToCurrent = () => setNewSegStart(currentTime.toFixed(1));
  const setEndToCurrent = () => setNewSegEnd(currentTime.toFixed(1));

  if (!url) {
    return (
      <div className="text-center py-20">
        <p className="text-zinc-500 mb-4">No video loaded.</p>
        <button onClick={() => navigate('/')} className="text-teal-400">Go Home</button>
      </div>
    );
  }

  return (
    <div className={cn("transition-all duration-500", focusMode ? "fixed inset-0 z-50 bg-black" : "")}>
      <div className={cn("container mx-auto", focusMode ? "h-screen flex flex-col justify-center px-4" : "space-y-6")}>
        
        {/* Header / Controls (Hidden in Focus Mode unless hovered? For now just hide completely or show minimal) */}
        {!focusMode && (
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-semibold text-white truncate max-w-md">
              {videoData?.title || 'Watching Video'}
            </h1>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setFocusMode(true)}
                className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-white px-3 py-1.5 rounded text-sm transition-colors"
              >
                <Eye className="w-4 h-4" />
                Focus Mode
              </button>
              <button 
                onClick={handleSave}
                className="flex items-center gap-2 bg-teal-600 hover:bg-teal-500 text-white px-3 py-1.5 rounded text-sm transition-colors"
              >
                <Save className="w-4 h-4" />
                {videoData ? 'Save Changes' : 'Save Video'}
              </button>
            </div>
          </div>
        )}

        {/* Player Container */}
        <div className={cn("relative bg-black rounded-xl overflow-hidden shadow-2xl ring-1 ring-white/10 mx-auto", focusMode ? "w-full max-w-6xl aspect-video" : "aspect-video")}>
          <RP
            ref={playerRef}
            url={url}
            width="100%"
            height="100%"
            controls={true} // We use native controls for simplicity, but we override behavior via API
            playing={playing}
            muted={muted}
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
            // onVolumeChange removed as it is not supported
            onProgress={handleProgress as any}
            config={{
              youtube: {
                playerVars: { showinfo: 0, rel: 0, modestbranding: 1 } as any
              } as any
            }}
          />
          
          {/* Focus Mode Exit Button */}
          {focusMode && (
            <button 
              onClick={() => setFocusMode(false)}
              className="absolute top-4 right-4 bg-black/50 hover:bg-black/80 text-white p-2 rounded-full backdrop-blur-md transition-colors"
            >
              <Minimize2 className="w-6 h-6" />
            </button>
          )}

          {/* Overlay for Muted State indication */}
          {muted && (
            <div className="absolute top-4 left-4 bg-red-500/80 text-white px-3 py-1 rounded-full text-xs font-bold backdrop-blur-md flex items-center gap-2 pointer-events-none">
              <VolumeX className="w-3 h-3" />
              MUTED
            </div>
          )}
        </div>

        {/* Tools Section (Hidden in Focus Mode) */}
        {!focusMode && (
          <div className="grid md:grid-cols-3 gap-8">
            {/* Segments List */}
            <div className="md:col-span-2 space-y-4">
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                  <SkipForward className="w-5 h-5 text-teal-400" />
                  Ad/Skip Segments
                </h3>
                
                {/* Add New Segment */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-6 p-4 bg-zinc-950/50 rounded-lg border border-zinc-800/50">
                  <div className="space-y-1">
                    <label className="text-xs text-zinc-500">Start (sec)</label>
                    <div className="flex gap-2">
                      <input 
                        type="number" 
                        value={newSegStart} 
                        onChange={e => setNewSegStart(e.target.value)}
                        placeholder="0.0"
                        className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-sm text-white focus:outline-none focus:border-teal-500"
                      />
                      <button onClick={setStartToCurrent} className="text-xs text-teal-400 hover:text-teal-300 whitespace-nowrap">Current</button>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-zinc-500">End (sec)</label>
                    <div className="flex gap-2">
                      <input 
                        type="number" 
                        value={newSegEnd} 
                        onChange={e => setNewSegEnd(e.target.value)}
                        placeholder="0.0"
                        className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-sm text-white focus:outline-none focus:border-teal-500"
                      />
                      <button onClick={setEndToCurrent} className="text-xs text-teal-400 hover:text-teal-300 whitespace-nowrap">Current</button>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-zinc-500">Action</label>
                    <select 
                      value={newSegType}
                      onChange={(e: any) => setNewSegType(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-sm text-white focus:outline-none focus:border-teal-500"
                    >
                      <option value="skip">Skip</option>
                      <option value="mute">Mute</option>
                    </select>
                  </div>
                  <div className="flex items-end">
                    <button 
                      onClick={addSegment}
                      className="w-full bg-teal-600 hover:bg-teal-500 text-white py-1.5 rounded text-sm font-medium transition-colors flex items-center justify-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> Add
                    </button>
                  </div>
                </div>

                {/* List */}
                {segments.length === 0 ? (
                  <p className="text-zinc-500 text-sm text-center py-4">No segments defined yet.</p>
                ) : (
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                    {segments.map(seg => (
                      <div key={seg.id} className="flex items-center justify-between bg-zinc-950 p-3 rounded border border-zinc-800/50 hover:border-zinc-700 transition-colors">
                        <div className="flex items-center gap-4">
                          <span className={cn("text-xs font-bold px-2 py-0.5 rounded uppercase", seg.type === 'skip' ? 'bg-blue-900 text-blue-200' : 'bg-red-900 text-red-200')}>
                            {seg.type}
                          </span>
                          <span className="text-sm text-zinc-300 font-mono">
                            {formatTime(seg.start)} — {formatTime(seg.end)}
                          </span>
                        </div>
                        <button 
                          onClick={() => removeSegment(seg.id)}
                          className="text-zinc-500 hover:text-red-400 transition-colors"
                        >
                          <VolumeX className="w-4 h-4" /> {/* Reuse icon for delete */}
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Notes Section */}
            <div>
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 h-full">
                <h3 className="font-semibold text-white mb-4">Notes</h3>
                <textarea 
                  className="w-full h-[200px] bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-sm text-white focus:outline-none focus:ring-1 focus:ring-teal-500 resize-none"
                  placeholder="Add notes about this video..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
