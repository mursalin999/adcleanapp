const express = require('express');
const db = require('../db');
const jwt = require('jsonwebtoken');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-key';

// Middleware to check auth
const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ error: 'No token provided' });
  
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

router.use(authenticate);

// Get all videos for user
router.get('/', (req, res) => {
  try {
    const videos = db.prepare(`
      SELECT v.*, vs.segments, vs.notes 
      FROM videos v 
      LEFT JOIN video_settings vs ON v.id = vs.video_id 
      WHERE v.user_id = ? 
      ORDER BY v.created_at DESC
    `).all(req.userId);
    
    // Parse JSON segments
    const formatted = videos.map(v => ({
      ...v,
      segments: v.segments ? JSON.parse(v.segments) : [],
    }));
    
    res.json(formatted);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Save a video
router.post('/', (req, res) => {
  const { platform, url, title, thumbnail } = req.body;
  
  try {
    const insertVideo = db.prepare('INSERT INTO videos (user_id, platform, url, title, thumbnail) VALUES (?, ?, ?, ?, ?)');
    const info = insertVideo.run(req.userId, platform, url, title, thumbnail);
    const videoId = info.lastInsertRowid;
    
    const insertSettings = db.prepare('INSERT INTO video_settings (video_id, segments, notes) VALUES (?, ?, ?)');
    insertSettings.run(videoId, '[]', '');
    
    res.status(201).json({ id: videoId, user_id: req.userId, platform, url, title, thumbnail, segments: [], notes: '' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update video settings
router.put('/:id', (req, res) => {
  const { segments, notes } = req.body;
  const videoId = req.params.id;
  
  try {
    // Verify ownership
    const video = db.prepare('SELECT id FROM videos WHERE id = ? AND user_id = ?').get(videoId, req.userId);
    if (!video) return res.status(404).json({ error: 'Video not found' });
    
    const update = db.prepare('UPDATE video_settings SET segments = ?, notes = ? WHERE video_id = ?');
    update.run(JSON.stringify(segments), notes, videoId);
    
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete video
router.delete('/:id', (req, res) => {
  const videoId = req.params.id;
  
  try {
    const video = db.prepare('SELECT id FROM videos WHERE id = ? AND user_id = ?').get(videoId, req.userId);
    if (!video) return res.status(404).json({ error: 'Video not found' });
    
    db.prepare('DELETE FROM videos WHERE id = ?').run(videoId);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
